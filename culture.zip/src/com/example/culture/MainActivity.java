package com.example.culture;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.StringTokenizer;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Vibrator;
import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

public class MainActivity extends Activity {

    private ArrayList<HashMap<String, String>> list_board = new ArrayList<HashMap<String, String>>();
    private HashMap<String, String> map;
    private SimpleAdapter sa;
    private ArrayList<String> contents;
    
    static final int PROGRESS_DIALOG = 0;
    private ListView lv;
    private TextView status;
    private static final int MSG_PASSING =1;
    private StringTokenizer tk;

    @Override
    public void onCreate(Bundle savedInstanceState){
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        final Vibrator vibe = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         //�̱��� �⺻
        status = (TextView)findViewById(R.id.textView1);
        lv = (ListView)findViewById(R.id.listView1);

        //��� ����Ʈ id �˻��� �Ҵ�
        sa = new SimpleAdapter(this, list_board, R.layout.borad, new String[]{"subject", "date", "content"},new int[]{R.id.board_subject, R.id.board_date, R.id.board_writer});
        lv.setAdapter(sa);
        
        contents = new ArrayList<String>();
        ((Button)findViewById(R.id.button1)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                new parser().execute(null,null,null);
                for(int i =0;i<list_board.size(); i=0){
                    HashMap<String, String> a = list_board.get(i);
                    String m = a.values().toString();
                    tk = new StringTokenizer(m,"[,]",true);
                    tk.nextToken();
                    String m1 = tk.nextToken();
                    tk.nextToken();
                    m1 = tk.nextToken();
                    tk.nextToken();
                    m1 = tk.nextToken();
                    tk.nextToken();
                    m1 = tk.nextToken();
                    tk.nextToken();
                    m1 = tk.nextToken();
                    String mcf = "";
                }

            }
        });
    }
    public class parser extends AsyncTask<String, String, String>{
        protected String doInBackground(String... params) {
            rssParse(((EditText)findViewById(R.id.editText1)).getText().toString());
            return null;
        }
        @Override
        protected void onPostExecute(String result) {
            sa.notifyDataSetChanged();
        }
    }
    private void rssParse(String url)
    {
        list_board.clear();
        try{
            URL text = new URL(url);
            XmlPullParserFactory parserCreator = XmlPullParserFactory.newInstance();
            XmlPullParser parser = parserCreator.newPullParser();
            parser.setInput(text.openStream(), null);

            int parserEvent = parser.getEventType();
            String tag = "";

            boolean inTitle = false;    //���񿩺��Ǵ�
            boolean inItem = false;     //�����ۺ��� �Ǵ�
            boolean inWriter = false;   //�ۼ��� �Ǵ�
            boolean inDate = false;     //�ۼ���
            boolean inContent = false;  //����
            boolean ingpsX = false; 
            boolean ingpsY = false;

            //XML ��¥ ���� ��ȯ�ϱ�
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy�� MM�� dd�� HH�� mm�� ss��");
            Date pubdate = null;
            int count = 0;
            contents.clear();      //������ �ִ� �������� ��� ����
            do{
                Log.i("test",""+count);
                switch(parserEvent){
                case XmlPullParser.TEXT:
                    tag = parser.getName();
                    //����
                    if(inItem && inTitle){
                        map.put("subject", parser.getText());
                    }
                    //�ۼ���
                    if(inItem && inDate){
                        map.put("date", parser.getText());
                    }
                    //����
                    if(inItem && inContent){
                        map.put("content", parser.getText());
                    }
                    if(inItem && ingpsX){
                        map.put("gpsX", parser.getText());
                    }
                    if(inItem && ingpsY){
                        map.put("gpxY", parser.getText());
                    }
                    break;

                case XmlPullParser.END_TAG:
                    tag = parser.getName();
                    //�±װ� ������
                    if(tag.compareTo("perforList") == 0){
                        inItem = false;
                        list_board.add(map);
                    }
                    if(tag.compareTo("title") == 0){
                        inTitle = false;
                    }
                    if(tag.compareTo("startDate") == 0){
                        inDate = false;
                    }
                    if(tag.compareTo("place") == 0){
                        inContent = false;
                    }
                    if(tag.compareTo("gpsX") == 0){
                        ingpsX = false;
                    }
                    if(tag.compareTo("gpsY") == 0){
                        ingpsY = false;
                    }
                    break;

                case XmlPullParser.START_TAG:
                    tag = parser.getName();
                    //���� item���� �����ϴ� �±׶��
                    if(tag.compareTo("perforList") == 0){
                        inItem = true;
                        map = new HashMap<String, String>();
                    }
                    //���� title �� �����ϴ� �±׶��
                    if(tag.compareTo("title") == 0){
                        inTitle = true;
                    }
                    //���� pubDate �±׶��
                    if(tag.compareTo("startDate") == 0){
                        inDate = true;
                    }
                    //���� description �±׶��
                    if(tag.compareTo("place") == 0){
                        inContent = true;
                    }
                    if(tag.compareTo("gpsX") == 0){
                        ingpsX = true;
                    }
                    if(tag.compareTo("gpsY") == 0){
                        ingpsY = true;
                    }
                    break;
                }
                parserEvent = parser.next();
                count++;
            }while(parserEvent != XmlPullParser.END_DOCUMENT);
        }catch(Exception e){}
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
}
